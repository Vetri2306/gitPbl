package practise;
import java.util.*;

public class practise {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

	
		String name1 = sc.nextLine();
	
		
		System.out.println("welcome " +name1);
	}
}
