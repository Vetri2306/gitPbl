package practise;

public class practise3 {

	public static void main(String[] args) {
		int a = -1300;
		
		if(a>0) {
		System.out.println("The give integer number is positive");
		}
		
		else if(a<0) {
		System.out.println("The given integer number is negative");
		
		}
		else {
			System.out.println("The given number is zero");
		}
		

	}

}
