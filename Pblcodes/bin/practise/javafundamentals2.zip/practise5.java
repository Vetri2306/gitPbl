
package practise;

import java.util.Scanner;

public class practise5 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		char val = sc.next().charAt(0);
		switch (val) {
		case 'r':
		System.out.println("red");
		break;
			
		case 'b':
		System.out.println("blue");
		break;
		
		case 'y':
		System.out.println("yellow");
		break;
		
		case 'g':
		System.out.println("green");
		break;
		
		case 'o':
			System.out.println("orange");
			break;
		case 'w':
			System.out.println("white");
			break;
				
		default :
		System.out.println("invalide code") ;
		
		
		}
	
		
		
			
		}

	}


