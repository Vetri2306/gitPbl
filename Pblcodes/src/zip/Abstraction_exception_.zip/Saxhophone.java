package music.wind;
import music.playable;
public class Saxhophone implements playable {
	
public void play() {
	
	System.out.println("saxhophone playing");
}

	
}
