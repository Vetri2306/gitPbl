package music;

public interface playable {

 void play();
}
