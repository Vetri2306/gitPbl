package music.string;
import music.playable;
public class veena implements playable{
	public void play() {
		System.out.println("veena playing");
	}

}
