package live;

import music.playable;
import music.string.*;
import music.wind.*;

public class test {
public static void main(String[] args) {
	playable veena =new veena();
	
	playable Saxhophone = new Saxhophone();
	veena.play();
	Saxhophone.play();
}
}
