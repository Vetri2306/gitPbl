package com.automobile;

public abstract class vehicle {

	
	public abstract String getmodelname();
	public abstract String getregistraionNo();
    public abstract String getownernane();
}
