package pack1;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class demo {

	@When("I hovered over the brand tab")
	public void i_hovered_over_the_brand_tab() {
		
	}

	@When("I searched a valid brand name")
	public void i_searched_a_valid_brand_name() {
		
	}

	@Then("I verified that brandname gat searched succesfully")
	public void i_verified_that_brandname_gat_searched_succesfully() {
		
	}

}
